import Foundation

//1. Придумать класс, методы которого могут завершаться неудачей и возвращать либо значение, либо ошибку Error?. Реализовать их вызов и обработать результат метода при помощи конструкции if let, или guard let.
//2. Придумать класс, методы которого могут выбрасывать ошибки. Реализуйте несколько throws-функций. Вызовите их и обработайте результат вызова при помощи конструкции try/catch.

enum MathErrors: Error {
    case sideAerror(sideA: Int)
    case sideBerror(sideB: Int)
    
    var localizedDescription: String {
        switch self {
        case .sideAerror(sideA: let sideA):
            return "\(sideA), заданное значение не может быть меньше или равно нулю. "
        case .sideBerror(sideB: let sideB):
            return "\(sideB), заданное значение не может быть меньше или равно нулю. "
        }
    }
}

class Triangle {
    let sideA: Int
    let sideB: Int
    
    init(sideA: Int, sideB: Int) {
        self.sideA = sideA
        self.sideB = sideB
    }
    
    func triangleArea () throws -> Int {
        guard sideA > 0 else {
            throw MathErrors.sideAerror(sideA: sideA)
        }
        
        guard sideB > 0 else {
            throw MathErrors.sideBerror(sideB: sideB)
        }
        
        return (sideA * sideB) / 2
    }
}

do {
    let triangle1 = try Triangle(sideA: 3, sideB: 4).triangleArea()
    print("Площадь прямоугольного треугольника равна \(triangle1)")
    
} catch MathErrors.sideAerror(sideA: let sideA) {
    print("Вы ввели неверное значение: \(sideA), так как значение не может быть меньше или равно 0.")
    
} catch MathErrors.sideBerror(sideB: let sideB) {
    print("Вы ввели неверное значение: \(sideB), так как значение не может быть меньше или равно 0.")

} catch let error {
    print(error)
}


